#pragma once

namespace BONE_FRAMEWORK
{
	BOOL FastCreateWindow(HINSTANCE _hInstance, HWND& hWnd, std::string _name, int _width, int _height);
}